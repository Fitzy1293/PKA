import csv
from pprint import pprint
with open('In PKA playlist.csv', encoding='utf8') as f:
    videos = csv.reader(f)
    videos = list(videos)

pprint(videos)

